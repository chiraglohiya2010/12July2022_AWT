$(document).ready(function(){
    $("#a").focus(function () { 
    $(this).css("background-color","red");
        
    });

    $("#b").blur(function(){
        $(this).css("background-color","purple");
    });

    $("#c").keypress(function(){
    
        alert($(this).val());
    });
    $("#d").keyup(function(){
    
        alert($(this).val());
    });
  });